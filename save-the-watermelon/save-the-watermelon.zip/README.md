# save-the-watermelon
it is basically just reflavored hangman, and I made it because I had to

## Run
```python -m src.game```

## How to test (commands).
just run it and TRY to break it, I dare you

## Features & rules.
robust input validation

it just functions like hangman, but you start with a couple letters revealed

## Known issues / limitations.
no known 'issues', really, just limitations:

category lists are stored directly in the words.py file

no special inputs or anything (ie., allow player to type something for a hint, or allowing the player to quit at any time, etc.)

## Credits (if any)
Brad for helping me get through the hellish 'explain your work' portion of this
